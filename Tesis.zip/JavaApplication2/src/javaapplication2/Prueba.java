/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author jtm5959
 */
public class Prueba {
   
    public static void main(String[] args){
        String dato;
        String data_Desc;
        data_Desc="";
        
        dato = "";
			for (int i = 0; i<550; i++){
				dato +=" ";
			}
			data_Desc += dato;
                        
                        System.out.println(data_Desc+"F");
                        
                        System.out.println(data_Desc.length());
        
}

    
}
