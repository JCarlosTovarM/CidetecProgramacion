/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import javax.swing.JOptionPane;

/**
 *
 * @author jtm5959
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*String track2data = "5174390000000000=181220100000465";
        int index = track2data.indexOf("=");
        String resto = track2data.substring(index + 1,track2data.length());
        System.out.println(resto);*/
        
        JOptionPane.showMessageDialog(null, "Datos incorrectos.\nVerifica tu información", "Error", 0);
        //JOptionPane.showMessageDialog(null, "Tu voto fue registrado", "Exito", 1);
        //JOptionPane.showMessageDialog(null, "Ya has votado previamente\nen esta eleccion", "Error", 0);
       /* try{
        String campo55="";
        String tagInfo=campo55;
        String msg="hola";
        if(msg!=null && tagInfo !=null && !tagInfo.isEmpty() && !campo55.isEmpty()){
             System.out.println("True");
        } else {
            System.out.println("False");
        }
        }catch(Exception e){
            System.out.println("e:"+e);
        }*/
       /*
       String prueba ="";
       try{
           if(prueba!=null){
           System.out.println("Estoy Aqui");
       }
       }catch(Exception e){
           System.out.println(e);
       }*/
       
       
        // TODO code application logic here
    }
    
}
